// routes/izin.js
const express = require('express');
const router = express.Router();
const absensiController = require('../controllers/absensiController');
const verifyToken = require('../middleware/authMiddleware');

router.post('/', verifyToken, absensiController.ajukanIzin);
router.get('/pegawai', verifyToken, absensiController.getRiwayatIzin);

module.exports = router;
