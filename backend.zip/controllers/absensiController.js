const db = require('../config/db');
const geolib = require('geolib');

// Lokasi kantor PTB Manyar
const kantorLat = -7.120436;
const kantorLng = 112.600460;
const radiusMeter = 20000;

// =====================
// ABSEN MASUK
// =====================
exports.absenMasuk = (req, res) => {
  let { latitude, longitude } = req.body;
  const user = req.user;

  latitude = parseFloat(latitude);
  longitude = parseFloat(longitude);

  const distance = geolib.getDistance(
    { latitude, longitude },
    { latitude: kantorLat, longitude: kantorLng }
  );

  if (distance > radiusMeter) {
    return res.status(403).json({
      message: 'Diluar radius lokasi kantor',
      distance
    });
  }

  const lokasi = `${latitude},${longitude}`;
  const sqlCek = `SELECT * FROM absensi WHERE pegawai_id = ? AND tanggal = CURDATE()`;

  db.query(sqlCek, [user.pegawai_id], (err, result) => {
    if (err) return res.status(500).json({ message: 'Error cek absensi', error: err });

    if (result.length > 0) {
      if (result[0].jam_keluar) {
        return res.status(409).json({
          message: 'Sudah absen masuk dan keluar hari ini',
          type: 'sudah_keluar',
          absen: formatRiwayat(result[0])
        });
      } else {
        return res.status(409).json({
          message: 'Sudah absen masuk hari ini',
          type: 'sudah_masuk',
          absen: formatRiwayat(result[0])
        });
      }
    }

    const keterlambatan = hitungKeterlambatan();
    const status = 'Hadir';

    const sqlInsert = `
      INSERT INTO absensi (pegawai_id, tanggal, jam_masuk, lokasi_masuk, status, keterlambatan)
      VALUES (?, CURDATE(), CURTIME(), ?, ?, ?)
    `;
    db.query(sqlInsert, [user.pegawai_id, lokasi, status, keterlambatan], (err2) => {
      if (err2) return res.status(500).json({ message: 'Gagal absen masuk', error: err2 });
      res.json({ message: 'Absensi masuk berhasil', type: 'masuk' });
    });
  });
};

// =====================
// ABSEN KELUAR
// =====================
exports.absenKeluar = (req, res) => {
  let { latitude, longitude } = req.body;
  const user = req.user;

  latitude = parseFloat(latitude);
  longitude = parseFloat(longitude);
  const lokasi = `${latitude},${longitude}`;

  const sqlCek = `SELECT * FROM absensi WHERE pegawai_id = ? AND tanggal = CURDATE()`;

  db.query(sqlCek, [user.pegawai_id], (err, result) => {
    if (err) return res.status(500).json({ message: 'Error cek absensi', error: err });

    if (result.length === 0) {
      return res.status(404).json({ message: 'Belum absen masuk hari ini' });
    }

    if (result[0].jam_keluar) {
      return res.status(409).json({
        message: 'Sudah absen keluar hari ini',
        type: 'sudah_keluar',
        absen: formatRiwayat(result[0])
      });
    }

    const sqlUpdate = `
      UPDATE absensi 
      SET jam_keluar = CURTIME(), lokasi_keluar = ? 
      WHERE pegawai_id = ? AND tanggal = CURDATE()
    `;
    db.query(sqlUpdate, [lokasi, user.pegawai_id], (err2) => {
      if (err2) return res.status(500).json({ message: 'Gagal absen keluar', error: err2 });
      res.json({ message: 'Absensi keluar berhasil', type: 'keluar' });
    });
  });
};

// =====================
// RIWAYAT ABSENSI
// =====================
exports.getRiwayat = (req, res) => {
  const pegawai_id = req.user.pegawai_id;
  const sql = `SELECT * FROM absensi WHERE pegawai_id = ? ORDER BY tanggal DESC`;

  db.query(sql, [pegawai_id], (err, results) => {
    if (err) return res.status(500).json({ message: 'Gagal mengambil riwayat', error: err });

    const formatted = results.map(formatRiwayat);
    res.json(formatted);
  });
};

// =====================
// STATISTIK PEGAWAI
// =====================
exports.getStatistikPegawai = (req, res) => {
  const pegawai_id = req.user.pegawai_id;
  const sql = `
    SELECT 
      SUM(CASE WHEN status = 'Hadir' THEN 1 ELSE 0 END) AS hadir,
      SUM(CASE WHEN status = 'Tidak Hadir' THEN 1 ELSE 0 END) AS alpha,
      SUM(CAST(keterlambatan AS UNSIGNED)) AS keterlambatan
    FROM absensi
    WHERE pegawai_id = ? AND MONTH(tanggal) = MONTH(CURDATE()) AND YEAR(tanggal) = YEAR(CURDATE())
  `;

  db.query(sql, [pegawai_id], (err, results) => {
    if (err) return res.status(500).json({ message: 'Gagal mengambil statistik', error: err });

    const { hadir = 0, alpha = 0, keterlambatan = 0 } = results[0] || {};
    const total = hadir + alpha;
    const persen = total ? Math.round((hadir / total) * 100) : 0;

    res.json({
      hadir,
      alpha,
      keterlambatan,
      persen,
      keterlambatan_formatted: formatKeterlambatan(keterlambatan)
    });
  });
};

// =====================
// FUNGSI TAMBAHAN
// =====================
function hitungKeterlambatan() {
  const now = new Date();
  const jamMasuk = new Date(now);
  jamMasuk.setHours(8, 0, 0, 0);
  const selisihMs = now - jamMasuk;
  const selisihMenit = Math.floor(selisihMs / 60000);
  return selisihMenit > 0 ? selisihMenit : 0;
}

function formatKeterlambatan(menit) {
  const jam = Math.floor(menit / 60);
  const sisaMenit = menit % 60;
  if (jam > 0 && sisaMenit > 0) return `${jam} jam ${sisaMenit} menit`;
  if (jam > 0) return `${jam} jam`;
  return `${sisaMenit} menit`;
}

function formatRiwayat(item) {
  const keterlambatan = item.keterlambatan !== null ? formatKeterlambatan(item.keterlambatan) : '-';
  const persen = (item.jam_masuk && item.jam_keluar) ? '100%' : '-';
  const status = !item.jam_keluar ? 'Belum Pulang' : 'Selesai';
  const tanggalFormatted = new Date(item.tanggal).toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });

  return {
    ...item,
    tanggal: tanggalFormatted,
    keterlambatan,
    persen,
    status
  };
}
